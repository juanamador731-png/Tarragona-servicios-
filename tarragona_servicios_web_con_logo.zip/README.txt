# Tarragona Servicios — web inicial

Abre `index.html` en un navegador para ver la web.

ANTES DE PUBLICAR:
1. Sustituir `34XXXXXXXXX` por el número de WhatsApp real.
2. Decidir el nombre/marca definitivo.
3. Añadir fotos reales y opiniones reales cuando las tengamos.
4. Publicar en un hosting y conectar un dominio.

La estructura está preparada para crecer con páginas de servicios, SEO, formulario y zona para inmobiliarias.
